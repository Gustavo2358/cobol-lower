window.SEMANTIC_COVERAGE_DATA={
"meta":{"source":"literal.cbl","complete":true,"unresolvedCopies":0,"lexerErrors":0,"parserErrors":0},
"constructionCounts":{"INPUT_MISSING":0,"MODELED":2,"PRESERVED_UNINTERPRETED":0,"UNSUPPORTED":0},
"dependencyCounts":{"DEPENDENCY_UNKNOWN":0,"NOT_DEPENDENCY_BEARING":1,"REFERENCE_READY":1},
"metrics":{"dataReferences":0,"qualifiedDataReferences":0,"subscriptedDataReferences":0,"modifiedDataReferences":0,"preservedDataReferences":0,"procedureReferences":0,"fileReferences":0,"programReferences":1,"modeledStatements":0,"preservedStatements":0,"typedDataClauses":0,"preservedDataClauses":0,"opaqueExpressions":0,"embeddedLanguages":0},
"findings":[{"id":0,"ast":5,"parse":22,"line":4,"sourceLine":4,"rule":"callStatement","coverage":"MODELED","dependency":"REFERENCE_READY","sourceFile":"literal.cbl","text":"CALL 'PROGA'","reason":"Statement has a dedicated AST node; nested semantic detail may still remain incomplete."},{"id":1,"ast":8,"parse":29,"line":5,"sourceLine":5,"rule":"gobackStatement","coverage":"MODELED","dependency":"NOT_DEPENDENCY_BEARING","sourceFile":"literal.cbl","text":"GOBACK","reason":"Flow statement is structurally modeled and does not itself name a dependency."}],
"blockingReasons":[]};
